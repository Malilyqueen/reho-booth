#!/bin/bash
cd ..
python api.py